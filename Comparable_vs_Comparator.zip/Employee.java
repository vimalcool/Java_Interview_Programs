public class Employee  implements Comparable<Employee> {

private Integer empID;
private String empName;
private Double empSalary;

    public Employee(Integer empID, String empName, Double empSalary) {
        this.empID = empID;
        this.empName = empName;
        this.empSalary = empSalary;
    }

    public Integer getEmpID() {
        return empID;
    }

    public String getEmpName() {
        return empName;
    }

    public Double getEmpSalary() {
        return empSalary;
    }

    @Override
    public String toString() {
        return "Employee{" +
                "empID=" + empID +
                ", empName='" + empName + '\'' +
                ", empSalary=" + empSalary +
                '}';
    }

    @Override
    public int compareTo(Employee o) {
        return this.getEmpID().compareTo(o.getEmpID());
    }
}

