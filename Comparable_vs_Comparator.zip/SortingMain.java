
import java.util.*;

public class SortingMain {

    public static void main(String[] args) {
        List<Employee> list=new ArrayList<>();
        list.add(new Employee(5,"Dinesh",40000.00));
        list.add(new Employee(1,"Ajay",15000.00));
        list.add(new Employee(4,"Sowmiya",30000.00));
        list.add(new Employee(6,"harish",25000.00));




        Comparator<Employee> com=new Comparator<Employee>() {
            @Override
            public int compare(Employee o1, Employee o2) {
                return o2.getEmpName().compareTo(o1.getEmpName());
            }
        };

        Collections.sort(list, com);

        for(Employee i:list)
        {
            System.out.println(i);
        }


    }

}
